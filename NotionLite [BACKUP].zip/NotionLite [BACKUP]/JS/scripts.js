function showAlert() {
        alert("Bro it's 2025, learn English.");
    }


    